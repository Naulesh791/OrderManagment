package com.microservices.customerms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.customerms.dao.CustomerDao;
import com.microservices.customerms.model.Customer;

@Service
public class CustomerService {
	
	@Autowired
	CustomerDao custDao;
	
	public void save(Customer product) {
		custDao.save(product); 
	}
	
	
	public List<Customer> getAllCustomers(){
		return custDao.findAll();
	}
	
	
	public Customer getCustomerById(int id) {
		return custDao.findById(id).get();
	}

}
