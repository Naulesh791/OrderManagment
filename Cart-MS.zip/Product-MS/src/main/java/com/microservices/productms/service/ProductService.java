package com.microservices.productms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.productms.dao.ProductDao;
import com.microservices.productms.model.Product;

@Service
public class ProductService {
	
	@Autowired
	ProductDao productDao;
	
	public void save(Product product) {
		productDao.save(product); 
	}
	
	
	public List<Product> getAllProducts(){
		return productDao.findAll();
	}
	
	
	public Product getProductById(int id) {
		return productDao.findById(id).get();
	}
	
	public List<Product> getProductByName(String name) {
		return productDao.findByName(name);
	}

}
