package com.microservices.productms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.productms.model.Product;
import com.microservices.productms.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/product") 
    public ResponseEntity<Product> saveProduct(@RequestBody Product product)  {
		productService.save(product);
    	  return new ResponseEntity<Product>(product,HttpStatus.CREATED);
    }
    
    
    @GetMapping("/products")
    public List<Product> getAllProducts(){
    	return productService.getAllProducts();
    }
    
    
    @GetMapping("/product/{id}")
    public Product getProductById(@PathVariable("id") int id ) {
		return productService.getProductById(id);
    	
    }

    @GetMapping("/products/{name}")
    public List<Product> getProductByName(@PathVariable("name") String name ) {
		return productService.getProductByName(name);
    	
    }
}
