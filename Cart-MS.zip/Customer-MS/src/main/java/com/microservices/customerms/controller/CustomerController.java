package com.microservices.customerms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.customerms.model.Customer;
import com.microservices.customerms.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService custService;
	
	@PostMapping("/customer") 
    public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer)  {
		custService.save(customer);
    	  return new ResponseEntity<Customer>(customer,HttpStatus.CREATED);
    }
    
    
    @GetMapping("/customers")
    public List<Customer> getAllCustomers(){
    	return custService.getAllCustomers();
    }
    
    
    @GetMapping("/customer/{id}")
    public Customer getCustomerById(@PathVariable("id") int id ) {
		return custService.getCustomerById(id);
    	
    }

   
}
