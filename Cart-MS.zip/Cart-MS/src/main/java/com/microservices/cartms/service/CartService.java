package com.microservices.cartms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.cartms.dao.CartDao;
import com.microservices.cartms.model.Cart;

@Service
public class CartService {
	
	@Autowired
	CartDao custDao;
	
	public void save(Cart product) {
		custDao.save(product); 
	}
	
	
	
	public List<Cart> getProductsByCartid(String cartid) {
		return custDao.findByCartId(cartid);
	}
	
	public List<Cart> getCumulativeCartPrice(String cartid) {
		return custDao.findByCartId(cartid);
	}

}
