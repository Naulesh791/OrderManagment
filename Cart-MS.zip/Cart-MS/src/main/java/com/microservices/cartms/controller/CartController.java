package com.microservices.cartms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.cartms.model.Cart;
import com.microservices.cartms.service.CartService;

@RestController
public class CartController {
	
	Double cumulativeprice=0.0;
	
	@Autowired
	CartService cartService;
	
	@PostMapping("/cart") 
    public ResponseEntity<Cart> addProduct(@RequestBody Cart cart)  {
		cartService.save(cart);
    	  return new ResponseEntity<Cart>(cart,HttpStatus.CREATED);
    }

    
    
    @GetMapping("/cart/{cartid}")
    public List<Cart> getProductsByCartid(@PathVariable("cartid") String cartId ) {
		return cartService.getProductsByCartid(cartId);
    	
    }
    
    @GetMapping("/cartprice/{cartid}")
    public Double getCumulativeCartPrice(@PathVariable("cartid") String cartId ) {
       	for(Cart cart : cartService.getCumulativeCartPrice(cartId)) {
       		cumulativeprice=cumulativeprice + cart.getProductPrice();
    		System.out.println("cumulativeprice "+cumulativeprice);
    	}
		return cumulativeprice;
    	
    }

   
}
