package com.microservices.cartms.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cart {
	

	private String cartId;
	@Id
	private int productId;
	private String productName;
	private Double productPrice;
	
	
	
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	
	
	
	
	
}
